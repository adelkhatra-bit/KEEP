-- Tâche 2 (audit 07/10/2026, Adel) — migration ADDITIVE, aucune donnée supprimée.
-- 1) Tableau de bord : « payants » n'inclut plus les abonnements offerts (source admin_grant) ni les comptes masqués de test ;
--    nouveaux compteurs activeOffered et testAccounts.
-- 2) Goûts : le cœur, le pouce bas et « masquer » dans Loki Pulse apprennent enfin à l'algorithme
--    (même moteur signé que GARDER / écoute : keep_apply_track_taste_signal, bornes -20..250).
-- 3) Catalogue mondial : la tâche planifiée qui vide la file d'agrandissement n'existait plus en base (2 531 en attente) ;
--    on la recrée toutes les 5 minutes (au lieu de 2) pour ménager Postgres.

-- 1) Tableau de bord ---------------------------------------------------------------------------------------------------
create or replace function public.admin_dashboard_stats(p_from date default (current_date - 29), p_to date default current_date, p_country text default null::text)
returns jsonb
language plpgsql
security definer
set search_path to ''
as $function$
declare
  v_uid uuid := auth.uid();
  v_from timestamptz;
  v_to timestamptz;
  v_country text := nullif(upper(btrim(coalesce(p_country,''))), '');
  v_result jsonb;
begin
  if not exists(select 1 from public.admin_users a where a.id=v_uid and a.is_active=true) then
    raise exception 'admin_required' using errcode='42501';
  end if;
  if p_from is null or p_to is null or p_from > p_to or p_to - p_from > 3660 then raise exception 'invalid_date_range'; end if;
  v_from := p_from::timestamptz;
  v_to := (p_to + 1)::timestamptz;

  select jsonb_build_object(
    'from',p_from,'to',p_to,'country',v_country,
    -- Comptes réels seulement : les comptes masqués (tests, admin) sont comptés à part dans testAccounts.
    'usersTotal',(select count(*) from public.profiles p where coalesce(p.discovery_hidden,false)=false and (v_country is null or p.country_code::text=v_country)),
    'testAccounts',(select count(*) from public.profiles p where coalesce(p.discovery_hidden,false)=true and (v_country is null or p.country_code::text=v_country)),
    'newUsers',(select count(*) from public.profiles p where coalesce(p.discovery_hidden,false)=false and p.created_at>=v_from and p.created_at<v_to and (v_country is null or p.country_code::text=v_country)),
    'verifiedEmails',(select count(*) from public.profiles p join auth.users u on u.id=p.id where coalesce(p.discovery_hidden,false)=false and u.email_confirmed_at is not null and u.email is not null and u.email not like '%@keep.local' and (v_country is null or p.country_code::text=v_country)),
    'activePaid',(select count(distinct s.profile_id) from public.subscriptions s join public.profiles p on p.id=s.profile_id join public.plans pl on pl.id=s.plan_id where s.status in ('ACTIVE'::public.subscription_status,'TRIALING'::public.subscription_status) and pl.code::text<>'FREE' and coalesce(s.source::text,'')<>'admin_grant' and coalesce(p.discovery_hidden,false)=false and (s.current_period_end is null or s.current_period_end>now()) and (v_country is null or p.country_code::text=v_country)),
    'activeOffered',(select count(distinct s.profile_id) from public.subscriptions s join public.profiles p on p.id=s.profile_id join public.plans pl on pl.id=s.plan_id where s.status in ('ACTIVE'::public.subscription_status,'TRIALING'::public.subscription_status) and pl.code::text<>'FREE' and coalesce(s.source::text,'')='admin_grant' and (s.current_period_end is null or s.current_period_end>now()) and (v_country is null or p.country_code::text=v_country)),
    'keeps',(select count(*) from public.keep_decisions k join public.profiles p on p.id=k.profile_id where k.decision='KEPT' and k.created_at>=v_from and k.created_at<v_to and (v_country is null or p.country_code::text=v_country)),
    'follows',(select count(*) from public.follows f join public.profiles p on p.id=f.follower_id where f.created_at>=v_from and f.created_at<v_to and (v_country is null or p.country_code::text=v_country)),
    'shares',(select count(*) from public.product_events e where e.created_at>=v_from and e.created_at<v_to and (v_country is null or e.country_code::text=v_country)),
    'eventsCreated',(select count(*) from public.events e where e.created_at>=v_from and e.created_at<v_to and (v_country is null or e.country_code::text=v_country)),
    'dailySignups',coalesce((select jsonb_agg(x order by x->>'date') from (select jsonb_build_object('date',d::date,'count',count(p.id)) x from generate_series(p_from,p_to,'1 day'::interval) d left join public.profiles p on p.created_at>=d and p.created_at<d+'1 day'::interval and coalesce(p.discovery_hidden,false)=false and (v_country is null or p.country_code::text=v_country) group by d) q),'[]'::jsonb),
    'planMix',coalesce((select jsonb_agg(jsonb_build_object('plan',plan_code,'count',cnt) order by plan_code) from (select coalesce(ap.code,'FREE')::text plan_code,count(*) cnt from public.profiles p left join lateral (select case when coalesce(s.source::text,'')='admin_grant' then pl.code::text||' (offert)' else pl.code::text end code from public.subscriptions s join public.plans pl on pl.id=s.plan_id where s.profile_id=p.id and s.status in ('ACTIVE'::public.subscription_status,'TRIALING'::public.subscription_status) and (s.current_period_end is null or s.current_period_end>now()) order by s.updated_at desc limit 1) ap on true where coalesce(p.discovery_hidden,false)=false and (v_country is null or p.country_code::text=v_country) group by coalesce(ap.code,'FREE')) z),'[]'::jsonb),
    'sharesByChannel',coalesce((select jsonb_agg(jsonb_build_object('channel',channel,'count',cnt) order by cnt desc) from (select coalesce(channel,'other') channel,count(*) cnt from public.product_events e where e.created_at>=v_from and e.created_at<v_to and (v_country is null or e.country_code::text=v_country) group by coalesce(channel,'other')) z),'[]'::jsonb),
    'countryMix',coalesce((select jsonb_agg(jsonb_build_object('country',country,'count',cnt) order by cnt desc) from (select coalesce(nullif(p.country_code::text,''),'--') country,count(*) cnt from public.profiles p where coalesce(p.discovery_hidden,false)=false group by coalesce(nullif(p.country_code::text,''),'--')) z),'[]'::jsonb)
  ) into v_result;
  return v_result;
end;
$function$;

-- 2) Goûts : cœur, pouce bas, masquer ----------------------------------------------------------------------------------
-- Échelle du moteur existant : GARDER = +8, écoute = +1,25. Cœur = +5, pouce bas = -8, masquer dans Pulse = -8.
-- Retirer un cœur / un pouce bas annule son effet.
create or replace function public.keep_taste_from_like_trigger()
returns trigger language plpgsql security definer set search_path to 'public'
as $function$
begin
  if tg_op='INSERT' then perform public.keep_apply_track_taste_signal(new.profile_id,new.track_id,5,true); return new; end if;
  if tg_op='DELETE' then perform public.keep_apply_track_taste_signal(old.profile_id,old.track_id,-5,false); return old; end if;
  return new;
end;
$function$;
revoke all on function public.keep_taste_from_like_trigger() from public,anon,authenticated;

drop trigger if exists trg_keep_taste_from_like on public.track_likes;
create trigger trg_keep_taste_from_like after insert or delete on public.track_likes
for each row execute function public.keep_taste_from_like_trigger();

create or replace function public.keep_taste_from_dislike_trigger()
returns trigger language plpgsql security definer set search_path to 'public'
as $function$
begin
  if tg_op='INSERT' then perform public.keep_apply_track_taste_signal(new.profile_id,new.track_id,-8,false); return new; end if;
  if tg_op='DELETE' then perform public.keep_apply_track_taste_signal(old.profile_id,old.track_id,8,true); return old; end if;
  return new;
end;
$function$;
revoke all on function public.keep_taste_from_dislike_trigger() from public,anon,authenticated;

drop trigger if exists trg_keep_taste_from_dislike on public.track_dislikes;
create trigger trg_keep_taste_from_dislike after insert or delete on public.track_dislikes
for each row execute function public.keep_taste_from_dislike_trigger();

create or replace function public.keep_taste_from_pulse_hidden_trigger()
returns trigger language plpgsql security definer set search_path to 'public'
as $function$
begin
  if new.hidden_at is not null and (tg_op='INSERT' or old.hidden_at is null) then
    perform public.keep_apply_track_taste_signal(new.profile_id,new.track_id,-8,false);
  end if;
  return new;
end;
$function$;
revoke all on function public.keep_taste_from_pulse_hidden_trigger() from public,anon,authenticated;

drop trigger if exists trg_keep_taste_from_pulse_hidden on public.profile_loki_pulse_events;
create trigger trg_keep_taste_from_pulse_hidden after insert or update of hidden_at on public.profile_loki_pulse_events
for each row execute function public.keep_taste_from_pulse_hidden_trigger();

-- 3) Catalogue mondial : tâche planifiée recréée (5 min) ---------------------------------------------------------------
select cron.unschedule(jobid) from cron.job where jobname='keep-world-catalog-expand-every-two-minutes';
select cron.unschedule(jobid) from cron.job where jobname='keep-world-catalog-expand-every-five-minutes';
select cron.schedule(
  'keep-world-catalog-expand-every-five-minutes',
  '*/5 * * * *',
  'select public.keep_enqueue_world_catalog_expansion();'
);
